import React from "react";
import {Body} from "./Style"

function Product() {
  return (
    <>
      <Body>
        <h1 className="product">Product</h1>
      </Body>
    </>
  );
}
export default Product;
