import React from "react";

function NotFound() {
  return <h1 className="notfound">NotFound</h1>;
}
export default NotFound;
