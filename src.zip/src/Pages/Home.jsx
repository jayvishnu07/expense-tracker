import React from "react"; 
import styled from "styled-components";
import HomeComponent from "../Components/TrackerComponents/HomeComponent";
import { useProfile } from "../Context/profile.context";
import { auth } from "../misc/Firebase";
import { defaultName } from "./Register";
import { toast } from 'react-toastify';


const Container = styled.div`
display: flex;
flex-direction: column;
font-family: Montserrat;
align-items : center;
margin: 30px 0 10px;
`;
const Header = styled.span`
color:black;
font-size : 25px;
font-weight : bold;
@media only screen and (max-width:960px){  
  transform: translateX(-25%);
  font-size : 18px;
}
`;

const SignOutClick = styled.button`
position: absolute;
right: 5%;
background:black;
color:white;
padding: 5px 10px;
border-radius: 4px;
cursor:pointer;
font-weight:bold;
font-size:15px;
`;

function Home() {

  const {profile} = useProfile();
 
  if(!profile){
    {
      toast.info('Login to Enter...!', {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      })
    }
  }



  const OnSignOutClicked=()=>{
    auth.signOut().then(
      toast.success('Sign-Out Successful...!', {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      })
    )
  }




  
  
  return(
  <Container>
    <Header>
       {`Hey, ${profile.displayName ? profile.displayName : defaultName} ...!`}

        </Header>
    <SignOutClick onClick={OnSignOutClicked} >Sign-Out</SignOutClick>
    <HomeComponent/>
  </Container> 
  ) 
  
}

export default Home;
