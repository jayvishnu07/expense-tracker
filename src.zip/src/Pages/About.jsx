import React from "react";
import {Body} from "./Style"

function About() {
  return (
    <>
      <Body>
        <h1 className="about">About</h1>
      </Body>
    </>
  );
}
export default About;
